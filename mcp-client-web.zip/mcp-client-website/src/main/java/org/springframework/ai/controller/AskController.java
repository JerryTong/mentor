package org.springframework.ai.controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.model.QuestionRequest;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AskController {

    private final ChatClient chatClient;

    public AskController(ChatClient.Builder chatClientBuilder, ToolCallbackProvider tools) {
        this.chatClient = chatClientBuilder.defaultTools(tools).build();
    }

    @GetMapping("/api/demo")
    public String getMethodName() {
        return "Hello world";
    }

    @PostMapping("/api/ask")
    public String askQuestion(@RequestBody QuestionRequest request) {
        try {
            return chatClient.prompt(request.getQuestion()).call().content();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
