package org.springframework.ai.model;

import lombok.Data;

@Data
public class QuestionRequest {
    private String question;
}