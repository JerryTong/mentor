package org.springframework.ai.mcp.sample.server;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ODAAStore {

    @JsonProperty("ser_no")
    private int serialNumber;

    @JsonProperty("end_dt")
    private String endDate;

    @JsonProperty("cat_title")
    private String categoryTitle;

    @JsonProperty("upload_item_file_id")
    private String uploadItemFileId;

    @JsonProperty("store_nm")
    private String storeName;

    @JsonProperty("city")
    private String city;

    @JsonProperty("type")
    private String type;

    @JsonProperty("store_intro")
    private String storeIntroduction;

    @JsonProperty("download_cnt")
    private int downloadCount;

    @JsonProperty("upd_tm")
    private String updateTime;

    @JsonProperty("score_avg")
    private double scoreAverage;

    @JsonProperty("start_dt")
    private String startDate;

    @JsonProperty("sts")
    private String status;

    @JsonProperty("img_path")
    private String imagePath;

    @JsonProperty("is_hot")
    private String isHot;

    @JsonProperty("store_types")
    private String storeTypes;
}
