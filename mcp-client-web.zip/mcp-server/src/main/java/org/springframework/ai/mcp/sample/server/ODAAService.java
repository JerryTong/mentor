package org.springframework.ai.mcp.sample.server;

import java.util.List;
import java.util.Map;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ODAAService {

    private final RestClient restClient;

    public ODAAService() {
        this.restClient = RestClient.builder()
                .defaultHeader("Content-Type", "application/json")
                .build();
    }

    @Tool(description = "國泰人壽Join享好康店家搜尋, 輸入參數有類別名(types)、台灣縣市城市名稱(city)，其中city非必填如果沒有選擇city則傳入預設ALL。類別有:美食饗宴、住宿旅遊、健康照護、運動健康、保戶專屬")
    public List<ODAAStore> getCathayLifeJoinStore(String types, String city) {

        String storeTypes = "";
        switch (types) {
            case "美食饗宴":
                storeTypes = "Y010";
                break;
            case "住宿旅遊":
                storeTypes = "Y030";
                break;
            case "健康照護":
                storeTypes = "Y050";
                break;
            case "運動健康":
                storeTypes = "Y020";
                break;
            case "保戶專屬":
                storeTypes = "Y070";
                break;
            default:
                break;
        }
        // 定義請求的 body
        Map<String, String> requestBody = Map.of(
                "store_types", storeTypes,
                "type", "Y");

        // 發送 POST 請求
        var response = restClient.post()
                .uri("https://patronc.cathaylife.com.tw/ODAA/api/DTODAA08/queryAllForFrontWithType")
                .body(requestBody)
                .retrieve()
                .body(String.class);

        // 使用 ObjectMapper 將 JSON 字串轉換為包含 data 的結構
        ObjectMapper objectMapper = new ObjectMapper();
        List<ODAAStore> stores = null;
        try {
            Map<String, Object> responseMap = objectMapper.readValue(response,
                    new TypeReference<Map<String, Object>>() {
                    });
            if (responseMap.containsKey("data")) {
                String dataJson = objectMapper.writeValueAsString(responseMap.get("data"));
                stores = objectMapper.readValue(dataJson, new TypeReference<List<ODAAStore>>() {
                });

                if (city != null && !city.equals("ALL")) {
                    // 只保留符合條件的商店
                    stores.removeIf(store -> !store.getCity().contains(city));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 返回商店列表
        return stores;
    }
}
